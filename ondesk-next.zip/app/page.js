
"use client";
import { motion } from "framer-motion";
import { Check, Phone, Mail, MapPin, Linkedin } from "lucide-react";

const NAV = [
  { label: "Services", href: "#services" },
  { label: "Approach", href: "#approach" },
  { label: "Case Studies", href: "#cases" },
  { label: "ROI", href: "#roi" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "#contact" },
];

const SERVICES = [
  { title: "PLM Implementations", points: ["WFX PLM setup & rollout","Adobe Illustrator connector","Libraries, BOMs, POM & workflows"] },
  { title: "ERP Integrations", points: ["NetSuite mapping & sync","BOM/Costing automation","Master data governance"] },
  { title: "Process Re-design", points: ["Concept → Sampling → Production","Vendor collaboration portals","Change management & adoption"] },
  { title: "Analytics & Readiness", points: ["KPI frameworks & dashboards","Data quality remediation","Executive reporting cadence"] },
  { title: "Data Governance", points: ["Taxonomies & coding standards","Item/Color/Season hierarchy","Audit & change log policies"] },
  { title: "Training & Enablement", points: ["Role‑based curricula","Train‑the‑trainer kits","Playbooks & SOPs"] },
];

const CASES = [
  { brand: "SKIMS (Illustrative)", img: "https://images.unsplash.com/photo-1520975922284-7b6831d4a6b0?q=80&w=800&auto=format&fit=crop", result: ["−25% sampling cycle time","+70% vendor portal adoption","Fewer BOM errors (top‑down templates)"] },
  { brand: "Everlane (Illustrative)", img: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=800&auto=format&fit=crop", result: ["Material reuse ↑ via libraries","Costing transparency across channels","Adobe‑to‑PLM asset traceability"] },
  { brand: "Tecovas (Illustrative)", img: "https://images.unsplash.com/photo-1503342217505-b0a15cf70489?q=80&w=800&auto=format&fit=crop", result: ["NetSuite sync reliability ↑","Connector governance & SLAs","Faster go‑to‑market"] },
];

import { useMemo, useState } from "react";

export default function Page() {
  const [inputs, setInputs] = useState({
    baselineCycleDays: 120,
    reductionPct: 20,
    annualStyles: 500,
    costPerStyleUSD: 250,
  });

  const output = useMemo(() => {
    const { baselineCycleDays, reductionPct, annualStyles, costPerStyleUSD } = inputs;
    const daysSaved = (baselineCycleDays * reductionPct) / 100;
    const savedPerStyleUSD = (daysSaved / baselineCycleDays) * costPerStyleUSD;
    const annualSavingsUSD = Math.round(savedPerStyleUSD * annualStyles);
    return { daysSaved, savedPerStyleUSD, annualSavingsUSD };
  }, [inputs]);

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur border-b bg-white/70">
        <div className="max-w-7xl mx-auto px-6 md:px-10 h-16 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-2 font-semibold">
            <span>✨</span>
            <span>Ondesk Consulting</span>
          </a>
          <nav className="hidden md:flex items-center gap-6 text-gray-600">
            {NAV.map(n => (
              <a key={n.href} href={n.href} className="hover:text-gray-900">{n.label}</a>
            ))}
          </nav>
          <div className="hidden md:block">
            <a href="#contact" className="px-4 py-2 rounded-2xl bg-blue-600 text-white">Let’s Talk</a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section id="top" className="pt-16 md:pt-24 max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <motion.div initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{duration:0.4}} className="space-y-6">
            <h1 className="text-3xl md:text-5xl font-semibold tracking-tight">
              Transforming fashion businesses with smarter <span className="underline decoration-blue-300">PLM & ERP</span> strategies
            </h1>
            <p className="text-gray-600 md:text-lg">
              10+ years • 200+ implementations • North America focus. We align systems, processes, and people—so your teams ship faster with fewer errors and measurable ROI.
            </p>
            <div className="flex flex-wrap gap-3">
              <a href="#services" className="px-5 py-3 rounded-2xl bg-blue-600 text-white">Explore Services</a>
              <a href="#contact" className="px-5 py-3 rounded-2xl border">Book a Discovery Call</a>
            </div>
            <ul className="flex flex-wrap gap-4 text-sm text-gray-500">
              <li className="flex items-center gap-2"><Check className="w-4 h-4"/> WFX PLM • NetSuite • Adobe</li>
              <li className="flex items-center gap-2"><Check className="w-4 h-4"/> Vendor Collaboration</li>
              <li className="flex items-center gap-2"><Check className="w-4 h-4"/> Data Governance</li>
            </ul>
          </motion.div>
          <div className="relative aspect-video w-full rounded-3xl overflow-hidden shadow-xl">
            <img src="https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?q=80&w=1600&auto=format&fit=crop" alt="Fashion tech workspace" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      {/* Logos */}
      <section className="py-10 md:py-14 max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-6 items-center opacity-80">
          {["AMIRI","SKIMS","Everlane","Tecovas","Mitchell & Ness","Gorjana"].map(b => (
            <div key={b} className="text-center text-xs md:text-sm tracking-wide text-gray-500 border rounded-2xl py-3">{b}</div>
          ))}
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-12 md:py-20 max-w-7xl mx-auto px-6 md:px-10">
        <div className="flex items-end justify-between mb-8">
          <h2 className="text-2xl md:text-4xl font-semibold">Services</h2>
          <a className="text-sm text-gray-500 hover:text-gray-800" href="#approach">See our approach →</a>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {SERVICES.map(s => (
            <div key={s.title} className="rounded-2xl border bg-white shadow-sm p-6">
              <div className="font-semibold text-lg mb-3">{s.title}</div>
              <ul className="space-y-2 text-sm text-gray-600">
                {s.points.map(p => (
                  <li key={p} className="flex items-start gap-2"><Check className="w-4 h-4 mt-0.5"/>{p}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Approach */}
      <section id="approach" className="py-12 md:py-20 max-w-7xl mx-auto px-6 md:px-10">
        <div className="flex items-end justify-between mb-8">
          <h2 className="text-2xl md:text-4xl font-semibold">A pragmatic, adoption‑first approach</h2>
          <a className="text-sm text-gray-500 hover:text-gray-800" href="#cases">See case studies →</a>
        </div>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            { title: "Discovery", text: "Map processes, pain points, data models, and readiness to change." },
            { title: "Design", text: "Blueprint PLM/ERP, libraries, vendors, costing and integrations." },
            { title: "Enable", text: "Cut‑scope rollout, training, change champions, vendor onboarding." },
            { title: "Govern", text: "KPIs, audit, cadence and continuous improvement playbooks." },
          ].map(step => (
            <div key={step.title} className="rounded-2xl border bg-white shadow-sm p-6">
              <div className="font-semibold text-lg mb-2">{step.title}</div>
              <p className="text-sm text-gray-600">{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Cases */}
      <section id="cases" className="py-12 md:py-20 max-w-7xl mx-auto px-6 md:px-10">
        <div className="flex items-end justify-between mb-8">
          <h2 className="text-2xl md:text-4xl font-semibold">Impact snapshots</h2>
          <a className="text-sm text-gray-500 hover:text-gray-800" href="#roi">Estimate ROI →</a>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {CASES.map(c => (
            <div key={c.brand} className="overflow-hidden rounded-2xl border bg-white shadow-sm">
              <img src={c.img} alt={c.brand} className="h-40 w-full object-cover"/>
              <div className="p-6">
                <div className="font-semibold text-lg mb-3">{c.brand}</div>
                <ul className="space-y-2 text-sm text-gray-600">
                  {c.result.map(r => (
                    <li key={r} className="flex items-start gap-2"><Check className="w-4 h-4 mt-0.5"/>{r}</li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ROI Calculator */}
      <section id="roi" className="py-12 md:py-20 max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid md:grid-cols-2 gap-8 items-start">
          <div>
            <h2 className="text-2xl md:text-4xl font-semibold mb-3">Estimate your ROI</h2>
            <p className="text-gray-600 mb-6">Quick calculator to approximate annual savings from cycle‑time reductions and process standardization.</p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-500">Baseline cycle (days)</label>
                <input type="number" value={inputs.baselineCycleDays} onChange={(e)=>setInputs(v=>({...v, baselineCycleDays:+e.target.value}))} className="border rounded-xl px-3 py-2 w-full"/>
              </div>
              <div>
                <label className="text-sm text-gray-500">Reduction (%)</label>
                <input type="number" value={inputs.reductionPct} onChange={(e)=>setInputs(v=>({...v, reductionPct:+e.target.value}))} className="border rounded-xl px-3 py-2 w-full"/>
              </div>
              <div>
                <label className="text-sm text-gray-500">Annual styles</label>
                <input type="number" value={inputs.annualStyles} onChange={(e)=>setInputs(v=>({...v, annualStyles:+e.target.value}))} className="border rounded-xl px-3 py-2 w-full"/>
              </div>
              <div>
                <label className="text-sm text-gray-500">Cost / style (USD)</label>
                <input type="number" value={inputs.costPerStyleUSD} onChange={(e)=>setInputs(v=>({...v, costPerStyleUSD:+e.target.value}))} className="border rounded-xl px-3 py-2 w-full"/>
              </div>
            </div>
          </div>
          <div className="rounded-2xl border bg-white shadow-sm p-6 space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="p-4 bg-gray-50 rounded-xl">
                <div className="text-gray-500">Days saved / style</div>
                <div className="text-2xl font-semibold">{output.daysSaved.toFixed(1)}</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-xl">
                <div className="text-gray-500">Save / style (USD)</div>
                <div className="text-2xl font-semibold">${output.savedPerStyleUSD.toFixed(2)}</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-xl col-span-2">
                <div className="text-gray-500">Annual savings (USD)</div>
                <div className="text-3xl font-semibold">${output.annualSavingsUSD.toLocaleString()}</div>
              </div>
            </div>
            <a href="#contact" className="block text-center px-5 py-3 rounded-2xl bg-blue-600 text-white">Discuss a detailed ROI model →</a>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-12 md:py-20 max-w-7xl mx-auto px-6 md:px-10">
        <h2 className="text-2xl md:text-4xl font-semibold mb-8">What leaders say</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { quote: "Ondesk brought structure to chaos. Adoption shot up once vendors were inside the same workflow.", name: "Director of Sourcing, US Apparel Brand" },
            { quote: "Their PLM‑ERP playbook eliminated duplicate work and gave leadership real‑time visibility.", name: "COO, Contemporary Fashion Label" },
            { quote: "Training was crisp, role‑based, and practical. Our teams started using PLM the same week.", name: "Head of Product Development, D2C Brand" },
          ].map(t => (
            <div key={t.name} className="rounded-2xl border bg-white shadow-sm p-6 space-y-4">
              <svg className="w-6 h-6 text-blue-600" viewBox="0 0 24 24" fill="currentColor"><path d="M7.17 6A5.17 5.17 0 0 0 2 11.17V22h8v-8H6.83A3.17 3.17 0 0 1 10 10.83V6H7.17Zm9 0A5.17 5.17 0 0 0 11 11.17V22h8v-8h-3.17A3.17 3.17 0 0 1 19 10.83V6h-2.83Z"/></svg>
              <p className="text-gray-600">{t.quote}</p>
              <div className="text-sm font-medium">{t.name}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-12 md:py-20 max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid md:grid-cols-2 gap-8 items-start">
          <div>
            <h2 className="text-2xl md:text-4xl font-semibold mb-3">Let’s build your transformation roadmap</h2>
            <p className="text-gray-600 mb-6">Share a few details and we’ll get back within one business day.</p>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2"><Phone className="w-4 h-4"/> +91 9582111197</div>
              <div className="flex items-center gap-2"><Mail className="w-4 h-4"/> pankaj.mrce89@gmail.com</div>
              <div className="flex items-center gap-2"><Linkedin className="w-4 h-4"/> <a className="underline" href="https://www.linkedin.com/in/pankaj-kumar9582111197" target="_blank" rel="noreferrer">LinkedIn Profile</a></div>
              <div className="flex items-center gap-2"><MapPin className="w-4 h-4"/> Gurgaon, Haryana, India</div>
            </div>
          </div>
          <div className="rounded-2xl border bg-white shadow-sm p-6 space-y-4">
            <div>
              <label className="text-sm text-gray-500">Your name</label>
              <input className="border rounded-xl px-3 py-2 w-full" placeholder="Jane Doe"/>
            </div>
            <div>
              <label className="text-sm text-gray-500">Work email</label>
              <input type="email" className="border rounded-xl px-3 py-2 w-full" placeholder="name@company.com"/>
            </div>
            <div>
              <label className="text-sm text-gray-500">Company</label>
              <input className="border rounded-xl px-3 py-2 w-full" placeholder="Brand / Manufacturer"/>
            </div>
            <div>
              <label className="text-sm text-gray-500">How can we help?</label>
              <textarea rows="4" className="border rounded-xl px-3 py-2 w-full" placeholder="Tell us about your goals, timelines, and current systems…"></textarea>
            </div>
            <a href="mailto:pankaj.mrce89@gmail.com?subject=Ondesk%20Consulting%20Inquiry" className="block text-center px-5 py-3 rounded-2xl bg-blue-600 text-white">Submit</a>
            <p className="text-xs text-gray-500">Submitting will open your email client with pre‑filled details if forms are disabled. For urgent requests, call or email directly.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t mt-10">
        <div className="max-w-7xl mx-auto px-6 md:px-10 py-10 grid md:grid-cols-4 gap-8">
          <div>
            <div className="font-semibold mb-2">Ondesk Consulting</div>
            <p className="text-sm text-gray-600">Fashion‑focused PLM & ERP consulting. Adoption first, ROI always.</p>
          </div>
          <div>
            <div className="font-medium mb-3">Explore</div>
            <ul className="space-y-2 text-sm text-gray-600">
              {NAV.map(n => (
                <li key={n.href}><a href={n.href}>{n.label}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <div className="font-medium mb-3">Contact</div>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-center gap-2"><Mail className="w-4 h-4"/> pankaj.mrce89@gmail.com</li>
              <li className="flex items-center gap-2"><Phone className="w-4 h-4"/> +91 9582111197</li>
              <li className="flex items-center gap-2"><Linkedin className="w-4 h-4"/> /in/pankaj-kumar9582111197</li>
            </ul>
          </div>
          <div>
            <div className="font-medium mb-3">Newsletter</div>
            <div className="flex gap-2">
              <input placeholder="your@work.com" className="border rounded-xl px-3 py-2 w-full"/>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-xl">Subscribe</button>
            </div>
            <p className="text-xs text-gray-500 mt-2">We send occasional insights on PLM/ERP adoption & ROI.</p>
          </div>
        </div>
        <div className="py-6 text-center text-xs text-gray-500">© {new Date().getFullYear()} Ondesk Consulting. All rights reserved.</div>
      </footer>
    </div>
  );
}
