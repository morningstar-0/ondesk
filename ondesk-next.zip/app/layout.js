export const metadata = {
  title: "Ondesk Consulting",
  description: "Fashion-focused PLM & ERP consulting. Adoption first, ROI always.",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-gradient-to-b from-white via-slate-50 to-white text-gray-800">
        {children}
      </body>
    </html>
  );
}
